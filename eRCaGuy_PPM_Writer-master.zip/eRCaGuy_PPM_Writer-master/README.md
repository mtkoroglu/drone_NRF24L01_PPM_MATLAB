Readme last updated: 2 July 2015

**Instructions**  


**Basic Summary**  
PPM writer. Connect to trainer port input on an RC Tx, through a 1k~10k resistor for protection to the Arduino and Radio.  

**Description**  


**For more information on this code see here:**

I hope you find this useful.  
Sincerely,  
Gabriel Staples  
http://www.ElectricRCAircraftGuy.com/  